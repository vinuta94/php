<html>
<body>
		<br>
	<?php $NAME=$_POST['name'];?>
	<h2>NAME:</h2>
<?php echo "$NAME";?><br>
	<?php $EMAIL=$_POST['email'];?>
	<h2>EMAIL:</h2>
<?php echo "$EMAIL";?><br>
	<h2>QUALIFICATION</h2>	<?php $QUALIFICATION=$_POST['text'];?>
<?php echo "$QUALIFICATION";?><br>
	<h2>PLACE:</h2>	<?php $PLACE=$_POST['place'];?>
<?php echo "$PLACE";?><br>

	<h2>UPLOAD IMAGE:</h2> <form action="upload.php" method="post" enctype="multipart/form-data">

 <input type="file" name="fileToUpload" id="fileToUpload">

<input type="submit" name="submit" value="submit">
</form>
	</body>
</html>
